-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2015 at 07:15 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `biometrics_site`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '$2y$10$bzU9yFYxotMiR7E7GbAe.uXJbr3BfIyT5rosujsujoeG59QUE2MxK');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
`id` int(11) NOT NULL,
  `day` date NOT NULL,
  `staff_id` varchar(6) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logout_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `day`, `staff_id`, `login_time`, `logout_time`) VALUES
(1, '2015-06-01', 'S-0001', '2015-06-01 07:00:00', '2015-06-01 15:00:00'),
(2, '2015-06-02', 'S-0001', '2015-06-02 07:00:00', '2015-06-02 15:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `leave_requests`
--

CREATE TABLE IF NOT EXISTS `leave_requests` (
`id` int(11) NOT NULL,
  `staff_id` varchar(6) NOT NULL,
  `request_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_approved` enum('PENDING','APPROVED','DISAPPROVED') NOT NULL,
  `type` enum('CASUAL','MATERNITY') NOT NULL,
  `reason` text NOT NULL,
  `request_start_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `request_duration` int(11) NOT NULL,
  `approved_start_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `approved_duration` int(11) NOT NULL,
  `date_approved` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `leave_requests`
--

INSERT INTO `leave_requests` (`id`, `staff_id`, `request_time`, `is_approved`, `type`, `reason`, `request_start_time`, `request_duration`, `approved_start_time`, `approved_duration`, `date_approved`) VALUES
(3, 'S-0001', '2015-06-04 05:42:27', 'PENDING', 'CASUAL', 'you know', '2014-12-31 23:00:00', 35, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00'),
(4, 'S-0001', '2015-06-04 05:43:45', 'APPROVED', 'CASUAL', '', '2014-12-31 23:00:00', 50, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00'),
(5, 'S-0001', '2015-06-04 05:43:50', 'DISAPPROVED', 'CASUAL', '', '2014-12-31 23:00:00', 25, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` varchar(6) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `other_names` varchar(30) NOT NULL,
  `department` varchar(30) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `finger_print` blob NOT NULL,
  `pic_url` text NOT NULL,
  `sex` enum('M','F') NOT NULL,
  `dob` date NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(13) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_suspended` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `password`, `first_name`, `last_name`, `other_names`, `department`, `designation`, `finger_print`, `pic_url`, `sex`, `dob`, `email`, `address`, `phone`, `is_deleted`, `is_suspended`) VALUES
('S-0001', '$2y$10$5O93JVLlz9Be1GwFKdL1Ne.98s/DaSrYdhQTcbUqWsrAJvgKxX/Oe', 'Chukwuemeka', 'Nwobodo', 'Joseph', 'ENGINEERS', 'MANAGER Designation', '', '', '', '2015-06-01', 'phoenixlabs.ng@gmail.com', '', '08133621591', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
 ADD PRIMARY KEY (`id`), ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `leave_requests`
--
ALTER TABLE `leave_requests`
 ADD PRIMARY KEY (`id`), ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
 ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `leave_requests`
--
ALTER TABLE `leave_requests`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
ADD CONSTRAINT `attendance_staff_id_constraint` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`);

--
-- Constraints for table `leave_requests`
--
ALTER TABLE `leave_requests`
ADD CONSTRAINT `leave_request_staff_id_constraint` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
