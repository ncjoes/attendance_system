<div class="bg-dark">
    <div class="container tertiary-text bg-dark fg-white" style="padding: 10px">
        &copy; Daw Ayebaboumobara        
    </div>
</div>