<?php

//Modify this constant values to suit your settings
//Do not commit this file afterwards

define("DEFAULT_DB_NAME", "biometrics_site"); //Default database name (Assuming there might be need for multiple databases)
define("DB_HOSTNAME", "localhost"); //Database hostname
define("DB_USERNAME", "root"); //Database username
define("DB_PASSWORD", ""); //Database password
define("HOSTNAME", "http://localhost/biometrics_site/"); //Location of this project in your computer (relative to localhost)
define("COMPANY_NAME", "Foo Enterprise");