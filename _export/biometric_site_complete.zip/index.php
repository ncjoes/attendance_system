<?php

//You can modify the cookies and be able to
//Detect the type of user and redirect to appropriate dir

header("Location: staff");